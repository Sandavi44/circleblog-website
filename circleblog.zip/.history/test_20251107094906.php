<?php
require_once 'config/db.php';
require_once 'config/session.php';
require_once 'includes/functions.php';

echo "✅ All files loaded successfully!<br>";
echo "✅ Database connected!<br>";
echo "✅ Base URL: " . getBaseUrl() . "<br>";
?>